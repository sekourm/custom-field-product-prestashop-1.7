Le fichier Product.php est à placer dans le dossier www/override/classes/
Attention à ne pas remplacer le fichier cible si existant.